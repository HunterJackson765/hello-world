# FlyCheck #

Useful plugin for moderators, to check the source of a player's flight - or lack of one.

Currently tracks

* Creative Mode
* [NoirFly](github.com/ZephireNZ/NoirFly)
* Bukkit Plugin

## Commands ##

`/flycheck [player]`

Shows the reason why a player is able to fly, or if they are not

## Permissions ##

`flycheck.check` - ability to use flycheck command