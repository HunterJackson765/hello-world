package me.zephirenz.noirguilds;

public class Perms {

    public static final String CREATE_OTHER = "noirguilds.create.other";
    public static final String CREATE = "noirguilds.create";
    public static final String DISBAND_OTHER = "noirguilds.disband.other";
    public static final String BANK_OTHER = "noirguilds.bank.other";

}
