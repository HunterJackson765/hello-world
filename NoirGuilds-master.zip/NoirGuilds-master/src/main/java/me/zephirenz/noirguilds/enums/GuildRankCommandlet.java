package me.zephirenz.noirguilds.enums;

public enum GuildRankCommandlet {

    CREATE,
    DELETE,
    EDIT,
    SET,
    LIST
}
