package me.zephirenz.noirguilds.enums;

public enum GuildCommandlet {
    INFO,
    CREATE,
    INVITE,
    KICK,
    EDIT,
    LEAVE,
    DISBAND,
    ACCEPT,
    DENY,
    MOTD,
    BANK,
    PAY,
    UPGRADE
}
